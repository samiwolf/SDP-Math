# toolbox.py
# Author: Andre Roberge
# You are free to use this code as you see fit.


import os
import pygame
from pygame.locals import *
import math


def new_image(filename, path=None, convert=True, key_pixel=None):
   ''' new_image() loads an image from a file, with the option of setting
       a given colour as being transparent.
       arguments:
           filename: name of the file containing the source image
       optional arguments:
           path: relative path (from the program to the image location)
           convert: set to None (or False) if you do not want the resulting
                    pygame Surface to have its pixel format converted.
           key_pixel: tuple of the form (x, y) specifying the
                      pixel location of a transparent colour
       returns:
           a tuple: pygame Surface object, pygame rect object
   '''
   if path:
       filename = os.path.join(path, filename)
   image = pygame.image.load(filename)
   if convert:
       image.convert()
   if key_pixel:
       colorkey = image.get_at(key_pixel)
       image.set_colorkey(colorkey, RLEACCEL)
   return image, image.get_rect()


def rotate_about(surf, angle, fixed_point="center"):
   ''' rotate_about() rotates a surface counterclockwise, about a fixed point.
       arguments:
           surf: pygame Surface object
           angle: rotation angle, expressed in degrees
       optional arguments:
           fixed_point: "center" (default value), "top_left", "top_right",
                        "bottom_left", "bottom_right"
       returns:
           a tuple: pygame Surface object, position tuple
           The position tuple is to be used as an argument in a blit operation.
           For example:
               rotated, position = rotate_about(surf, angle)
               screen.blit(rotated, position)
           will rotate the Surface "surf" about its center.
   '''
   rotated_surf = pygame.transform.rotate(surf, angle)
   # To maintain a fixed point, we need to make use of geometric and
   # trigonometric transformations, which are too complicated to
   # explain here in details
   w, h = surf.get_size()
   x = w/2
   y = h/2
   # trigonometric values with angle conversion
   deg2rad = math.pi/180
   rad_angle = angle*deg2rad
   cos = math.cos(rad_angle)
   sin = math.sin(rad_angle)
   # rotation of coordinates
   X1 = x*cos + y*sin
   Y1 = -x*sin + y*cos
   X2 = x*cos - y*sin
   Y2 = x*sin + y*cos


   X = max(abs(X1), abs(X2)) # 2*X, 2*Y == rotated_surf.get_size() !!
   Y = max(abs(Y1), abs(Y2))


   if fixed_point=="center":
       blit_shift = (int(x-X), int(y-Y))
   elif fixed_point =="top_left":
       blit_shift = (int(X1-X), int(Y1-Y))
   elif fixed_point =="top_right":
       blit_shift = (int(-X2+2*x-X), int(Y2-Y))
   elif fixed_point =="bottom_left":
       blit_shift = (int(X2-X), int(-Y2+2*y-Y))
   elif fixed_point =="bottom_right":
       blit_shift = (int(-X1+2*x-X), int(-Y1+2*y-Y))
   else:
       try:
           xx, yy = fixed_point
           xx -= x
           yy -= y
           X1 = xx*cos + yy*sin
           Y1 = -xx*sin + yy*cos
           blit_shift = (int(xx-X1-X), int(yy-Y1-Y))
           return rotated_surf, blit_shift
       except:
           return rotated_surf, (0, 0)


   return rotated_surf, blit_shift
