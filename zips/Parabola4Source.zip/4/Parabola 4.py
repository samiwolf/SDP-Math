import pygame
from pygame.locals import *
from math import *
from toolbox import new_image, rotate_about
import os, sys
pygame.init()
if sys.platform == 'win32' or sys.platform == 'win64':
    os.environ['SDL_VIDEO_CENTERED'] = '1'

print "Parabola Interactive Simulator - Version 4.0.0 - March 2008"
print "Ian Mallett"
print ""
print "A good setting for the screen's size is 800x600."
print ""

while True:
    width = raw_input("Enter the Screen's Width: ")
    try:
        width = abs(int(width))
        break
    except:
        print "Well now, let's try that again, shall we?"
while True:
    height = raw_input("Enter the Screen's Height: ")
    try:
        height = abs(int(height))
        break
    except:
        print "Well now, let's try that again, shall we?"

Screen = (width,height)
pygame.display.set_caption("Play with the Parabola!")
icon = pygame.Surface((1,1)); icon.set_alpha(0); pygame.display.set_icon(icon)
Surface = pygame.display.set_mode(Screen)

FocusPoint     = [Screen[0]/2,Screen[1]/2+1]
DirectrixPoint = [FocusPoint[0],FocusPoint[1]-40]
Selecting = None
ParabolaPoints = []
Diagonal = sqrt((Screen[0]**2)+(Screen[1]**2))
ParabolaSize = (Diagonal,Diagonal)

clock = pygame.time.Clock()

Font = pygame.font.Font(None, 16)

def Collide(p1,p2,radius):
    if ((p1[0]-p2[0])**2) + ((p1[1]-p2[1])**2) <= radius**2:
        return True
    return False
def GetInput():
    global Selecting, FocusPoint, DirectrixPoint
    key = pygame.key.get_pressed()
    mpress = pygame.mouse.get_pressed()
    mpos = pygame.mouse.get_pos()
    MousePos = (mpos[0],Screen[1]-mpos[1])
    for event in pygame.event.get():
        if event.type == QUIT or key[K_ESCAPE]:
            pygame.quit(); sys.exit()
    if mpress[0]:
        if   Selecting == "Focus Point"    :  FocusPoint     = MousePos
        elif Selecting == "Directrix Point":  DirectrixPoint = MousePos
    if   Collide(FocusPoint,    MousePos,4): Selecting = "Focus Point"
    elif Collide(DirectrixPoint,MousePos,4): Selecting = "Directrix Point"
    else: Selecting = None
def OnScreen(p):
    if p[0] < 0: return False
    if p[1] < 0: return False
    if p[0] > Screen[0]: return False
    if p[1] > Screen[1]: return False
    return True
def CalculateParabola(Rotation,FocusPoint,DirectrixPoint):
    #Find the Distance between the Focus and the Directrix.
    DistancePointSeparation = sqrt(((FocusPoint[0]-DirectrixPoint[0])**2)+((FocusPoint[1]-DirectrixPoint[1])**2))
    #For drawing the parabola, we'll use these artificial points rectified to 0 degree rotation.
    DP = (ParabolaSize[0]/2,0)
    FP = (DP[0],DistancePointSeparation)
    #Let's build the parabola!
    Points = []
    for x in xrange(int(ParabolaSize[0])):
        p = -((ParabolaSize[0]/2)-x)
        q = DistancePointSeparation
        if q == 0: q = 0.00000001
        h = q - (((q**2)-(p**2))/(2*q))
        Points.append((x,ParabolaSize[1]-h))
    #Parabola Surface
    ParabolaSurface = pygame.Surface(ParabolaSize)
    #Draw the Parabola
    pygame.draw.aalines(ParabolaSurface,(0,255,0),False,Points)
    #Rotate the Parabola and find where to draw it.
    s_c, position = rotate_about(ParabolaSurface,Rotation,(ParabolaSize[0]/2,ParabolaSize[1]))
    x = position[0]
    y = position[1] - (ParabolaSurface.get_height()/2)
    x += DirectrixPoint[0]
    y += Screen[1]-DirectrixPoint[1]
    #Draw the Parabola to the Screen
    Surface.blit(s_c, (x,y))
def Draw():
    Surface.fill((0,0,0))
    #Calculate Focus and Directrix Points
    FocusPosition     = (FocusPoint[0],Screen[1]-FocusPoint[1])
    DirectrixPosition = (DirectrixPoint[0],Screen[1]-DirectrixPoint[1])
    #Calculate Directrix
    XDiff = float(FocusPoint[0]-DirectrixPoint[0])
    YDiff = float(FocusPoint[1]-DirectrixPoint[1])
    if XDiff == 0: XDiff = 0.0000001
    if YDiff == 0: YDiff = 0.0000001
    SlopeSymAxis = YDiff/XDiff
    SlopeDirectrix = -(XDiff/YDiff)
    p1 = (0,(-SlopeDirectrix*DirectrixPoint[0])+DirectrixPoint[1])
    p2 = (Screen[0],p1[1]+(Screen[0]*SlopeDirectrix))
    #Calculate Dynamic Info.
    FPSText = Font.render("Frames/Second: "+str(int(round(clock.get_fps()))),True,(255,255,255))
    FocusPointText = Font.render("Focus Point: ("+str(FocusPoint[0])+", "+str(FocusPoint[1]-1)+")",True,(255,255,255))
    DirectrixControlPointText = Font.render("Directrix Control Point: ("+str(DirectrixPoint[0])+", "+str(DirectrixPoint[1]-1)+")",True,(255,255,255))
    if XDiff > 0: RotationInfo =    int(round(degrees(atan(SlopeSymAxis)))-90.0)
    else:         RotationInfo = -1*int(round(degrees(atan(-SlopeSymAxis)))-90.0)
    ParabolaRotationText = Font.render("Parabola Rotation: "+str(RotationInfo),True,(255,255,255))
    #Calculate and Draw Parabola
    CalculateParabola(RotationInfo,FocusPoint,DirectrixPoint)
    #Draw Focus and Directrix Points
    if   Selecting == "Focus Point"    : pygame.draw.circle(Surface,(255,255,200),FocusPosition,3)
    elif Selecting == "Directrix Point": pygame.draw.circle(Surface,(255,255,200),DirectrixPosition,3)
    pygame.draw.circle(Surface,(255,0,0),FocusPosition,2)
    pygame.draw.circle(Surface,(0,0,255),DirectrixPosition,2)
    #Draw Directrix
##    print "y = "+str(round(SlopeDirectrix,1))+"x + "+str(p1[1])
    pygame.draw.aaline(Surface, (0,0,255), (p1[0],Screen[1]-p1[1]),(p2[0],Screen[1]-p2[1]))
    #Draw Info.
    Surface.blit(FocusPointText,(10,10))
    Surface.blit(DirectrixControlPointText,(10,30))
    Surface.blit(ParabolaRotationText,(10,50))
    Surface.blit(FPSText,  (10,Screen[1]-80))
    Surface.blit(InfoText3,(10,Screen[1]-60))
    Surface.blit(InfoText2,(10,Screen[1]-40))
    Surface.blit(InfoText1,(10,Screen[1]-20))
    Surface.blit(FocusText,(FocusPosition[0]+10,FocusPosition[1]-5))
    Surface.blit(DirectrixText,(DirectrixPosition[0]+10,DirectrixPosition[1]-5))
    #Flip
    pygame.display.flip()
InfoText1 = Font.render("Ian Mallett - Version 4.0.0 - March 2008",True,(255,255,255))
InfoText2 = Font.render("Change the parabola by moving the focus and/or directrix control point.",True,(255,255,255))
InfoText3 = Font.render("ESCAPE key to exit.",True,(255,255,255))
FocusText = Font.render("Focus",True,(255,255,255))
DirectrixText = Font.render("Directrix CTRL Point",True,(255,255,255))
def main():
    while True:
        GetInput()
        Draw()
        clock.tick()
if __name__ == '__main__': main()
